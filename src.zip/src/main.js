import './scss/style.scss'
import music from './js/music.js'
import start from './js/start.js'
import tetris from './js/tetris.js'

start();
music();
tetris();